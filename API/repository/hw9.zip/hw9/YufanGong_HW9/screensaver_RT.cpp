//////////////////////////////////////////////////////////////////////////////
//  CIS554#Object-Oriented Programming in C++
//  HW_9
//  main function and RandomAttributes function to create and store shapes
//  Changed by Yufan Gong on 12/11/13.
//  screensaver_RT.cpp
//////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
// screensaver.cpp
// Author: Joe Waclawski
// Description: Simple screensaver to demonstrate MyRect class
/////////////////////////////////////////////////////////////////////
#include "MyRect.h"
#include "MyTriangle.h"
#include "MyCircle.h"
#include <stdlib.h> // rand and srand
#include <time.h> // time funciton
#include <windows.h>  // POINT object
#include <vector>
#include <map>

// small delay between drawing rectangles during each run
#define DRAW_DELAY 100

// small delay between each iteration of drawing rectangles
#define ITERATION_DELAY 250

enum SHAPE_TYPES {RECTANGLE, TRIANGLE, CIRCLE};

// function prototypes
void RandomAttributes(Shape *, int );


void main()
{
	int shapes; // loop index

	// seed the random number generator
	srand((unsigned int)time(0));

	// allow the user time to move the console window away
	// from the FilledShapes window are
	cout << "Move this window to the lower right of the screen, and press ENTER to continue:\n";
	cin.get();
	
	// vetors to store each shape type pointers
	vector<Shape *> rectVector;
    vector<Shape *> triangleVector;
    vector<Shape *> circleVector;
	//create a map to store shape pointers
	map<SHAPE_TYPES,vector<Shape *>> shapeMap;
		int rectCount = 0;
		int triaCount = 0;
		int circCount = 0;
		int SumCount;
		//ensure each shape displayed more than 20
		//ensure the map store at least 150 shapes
		do
		{
			//randomly to generate a type of shape
			int i = rand() % 3;
			if( i == 0 )
			{
				// create a derived pointer
				MyCircle *circle = new MyCircle();
				// assign derived class pointer to base class pointer
				Shape *MyShape = circle;
				RandomAttributes(MyShape, i);
				// put new shape to the rear of vector
				circleVector.push_back( MyShape );
				circCount++;
			}
			else if( i == 1 )
			{
				MyRect *rectang = new MyRect();
				Shape *MyShape = rectang;
				RandomAttributes(MyShape, i);
				rectVector.push_back( MyShape );
				rectCount++;
			}
			else if( i == 2 )
			{
				MyTriangle *triangle = new MyTriangle();
				Shape *MyShape = triangle;
				RandomAttributes(MyShape, i);
				triangleVector.push_back( MyShape);
				triaCount++;		
			}
			SumCount = rectCount + triaCount + circCount;
		}while (rectCount < 20 || triaCount < 20 || circCount < 20 || SumCount <150);
		
		//insert all shapes to the map, the map stores at least 150 shapes
		//we can also insert the first time, then update the map
		//I think this one is more simple here
		shapeMap.insert(pair<SHAPE_TYPES, vector<Shape *>>(RECTANGLE, rectVector));	
		shapeMap.insert(pair<SHAPE_TYPES, vector<Shape *>>(TRIANGLE, triangleVector));			
		shapeMap.insert(pair<SHAPE_TYPES, vector<Shape *>>(CIRCLE, circleVector));
		
		//judge the largest size to loop
		int largesize = (rectVector.size() > triangleVector.size() ) ? rectVector.size() : triangleVector.size();
		largesize = (largesize > circleVector.size())? largesize : circleVector.size();

		// enum type data
		SHAPE_TYPES type;
		map<SHAPE_TYPES,vector<Shape *>>::iterator mapIter;

		//each time show three different shapes on screen at first
		//if one type run over, then show two type, then one, until all shapes have been shown
		for (int i=0; i<largesize; i++)
		{
			MyCircle c;
			c.ClearScreen();
			for (int j=0; j<3; j++)
			{
				switch(j)
				{
					case 0: type = CIRCLE; break;
					case 1: type = RECTANGLE; break;
					case 2: type = TRIANGLE; break;
				}
				mapIter = shapeMap.find(type);
				// if the TYPE key is found
				if (mapIter != shapeMap.end())
				{
					// if the TYPE vector has something in it
					if ( !mapIter->second.empty() )
					{
						// draw the shape using polymorphism
						mapIter->second.back()->Draw();
						// VERY IMPORTANT - delete the memory at the pointer. we are done with the memory
						delete mapIter->second.back();
						// remove shape so we don�t display it again
						mapIter->second.pop_back();
					}
				}
			}
			if (DRAW_DELAY > 0)
				Sleep(DRAW_DELAY);
			if (ITERATION_DELAY > 0)
				Sleep(ITERATION_DELAY);
			//system("pause");
		}
}

/////////////////////////////////////////////////////////////////////
// RandomAttributes
// Description: This routine will randomy choose parameters for 
//              a Shape(MyRect, MyTriangle and MyCircle object, and draw it.
// 
// Inputs: Shape Pointer, a number indicate which derived class
// Outputs: None
// Returns: None
/////////////////////////////////////////////////////////////////////
void RandomAttributes(Shape *S, int random)
{
	//downcasting the baseclass shape pointer to derived class pointer
	switch (random)
	{
	case 0: S = dynamic_cast<MyCircle *>(S); break;
	case 1: S = dynamic_cast<MyRect *>(S); break;
	case 2: S = dynamic_cast<MyTriangle *>(S); break;
	default:
		break;
	}
	
	
	// needed to draw a filled shape
	POINT p;
	p.x=50;
	p.y=50;

	// define variables that will hold he parameters
	// for the rectangle
	SHAPE_COLOR firstColor=RED;
	SHAPE_COLOR lastColor=PURPLE;
	unsigned int myPen;
	unsigned int myBrush;
	unsigned int length;
	unsigned int width;
	unsigned int radius;

	// reset the rectangle object to some known, legal values
	S->SetPosition(p);
	S->SetLength(S->GetWindowHeight()/10);
	S->SetWidth(S->GetWindowWidth()/10);
	S->SetRadius(S->GetWindowHeight()/10);

	// generate random values for our parameters, within
	// allowable limits
	myPen = (unsigned int)firstColor + rand() % (unsigned int)lastColor;

	// make sure the pen and brush colors are not the same
	do {
		myBrush = (unsigned int)firstColor + rand() % (unsigned int)lastColor;
	} while (myBrush == myPen);

	// set up the parameters of the filled shape
	// object per the random data
	S->SetBorderColor((SHAPE_COLOR)myPen);
	S->SetFillColor((SHAPE_COLOR)myBrush);

	// stay in each loop until you have chosen random
	// parameters which draw a rectangle within the legal
	// limits of the window.

	// length
	do {
		length = 1 + rand() % S->GetWindowHeight();
	} while(!S->SetLength(length));

	// width
	do {
		width = 1 + rand() % S->GetWindowWidth();
	} while(!S->SetWidth(width));
	// radius
	do {
		radius = 1 + rand() % S->GetWindowHeight();
	} while(!S->SetRadius(radius));
	 //position
	do {
		p.x = 1 + rand() % S->GetWindowWidth();
		p.y = 1 + rand() % S->GetWindowHeight();
	} while(!S->SetPosition(p));
}



