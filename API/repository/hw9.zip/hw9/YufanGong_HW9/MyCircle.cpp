//////////////////////////////////////////////////////////////////////////////
//  CIS554#Object-Oriented Programming in C++
//  HW_9
//  Implementation of Class MyCircle
//  Created by Yufan Gong on 12/11/13.
//  MyCircle.cpp
//////////////////////////////////////////////////////////////////////////////

#include "MyCircle.h"

using std::cout;
using std::cin;
using std::endl;


///////////////////////////////////////////////////////////////////////////////
// MyCircle default constructor
///////////////////////////////////////////////////////////////////////////////
MyCircle::MyCircle()
// initialize default circle attributes
: circleradius(WINDOW_MAXY/4)
{}

///////////////////////////////////////////////////////////////////////////////
// MyCircle::Draw()
///////////////////////////////////////////////////////////////////////////////
bool MyCircle::Draw()
{
	// set up attributes of circle using FilledShapes
	fs.SetPenColor(borderColor);
	fs.SetBrushColor(fillColor);

	// draw circle with set attributes
	// when drawing, take into account the border width by subtracting the border
	// width appropriately from the radius. 
	fs.FilledCircle(position,circleradius-2*borderWidth);

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// MyCircle::SetRadius()
///////////////////////////////////////////////////////////////////////////////
bool MyCircle::SetRadius(unsigned int radius)
{
	// need to account for a min length and width based
	// upon the border width
	if ( radius <= 2*borderWidth ) return false;

	// check to make sure the new radius is valid based on current position
	// window height, and window width 
	if ( radius < ((GetWindowHeight()-position.y)/2) &&
		radius < ((GetWindowWidth()-position.x))/2)
	{
		circleradius = radius;
		return true;
	}
	else
	{
		return false;
	}
}

///////////////////////////////////////////////////////////////////////////////
// MyCircle::SetPosition()
///////////////////////////////////////////////////////////////////////////////
bool MyCircle::SetPosition(POINT & p)
{
	// make sure new position is valid based on current radius,
	// and window size
	if ( (p.x + circleradius + borderWidth) < GetWindowWidth() &&
		(p.x > (circleradius + borderWidth)) &&
		(p.y + circleradius + borderWidth) < GetWindowHeight() &&
		 (p.y > (circleradius + borderWidth))
		 )
	{
		position.x = p.x;
		position.y = p.y;
		return true;
	}
	else
	{
		return false;
	}
}

///////////////////////////////////////////////////////////////////////////////
// MyCircle::GetRadius()
///////////////////////////////////////////////////////////////////////////////
unsigned int MyCircle::GetRadius()
{
	return circleradius;
}
